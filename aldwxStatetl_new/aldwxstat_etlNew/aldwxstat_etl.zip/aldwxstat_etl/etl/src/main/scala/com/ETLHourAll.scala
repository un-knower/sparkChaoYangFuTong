package com

import aldwxutil.{TimeUtil, regex_rule}
import com.alibaba.fastjson.{JSON, JSONObject}
import org.apache.commons.lang.StringUtils
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, FileUtil, Path}
import org.apache.log4j.{Level, Logger}
import property.FieldName
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import java.security.MessageDigest
import java.sql.Connection
import java.text.SimpleDateFormat

import jdbc.MySqlPool


/**
  * Created by gaoxiang on 2018/1/11.
  */
object ETLHourAll {
  def main(args: Array[String]): Unit = {
    // 设置日志级别为WARN
    Logger.getLogger("org.apache.spark").setLevel(Level.WARN)
    val spark = SparkSession.builder()
      .appName(this.getClass.getName)
      .config("spark.speculation", true)
      .config("spark.sql.caseSensitive", true)
      .getOrCreate()
    val aldTimeUtil = new TimeUtil
    //获取今天时间
    val today = aldTimeUtil.processArgs(args)
    //获取当前小时的前一个小时
    val hour: String = aldTimeUtil.processArgsHour(args)
    jsonEtlHour(spark, aldTimeUtil, today, hour)

    spark.stop()
  }

  def jsonEtlHour(spark: SparkSession, aldTimeUtil: TimeUtil, today: String, hour: String): Unit = {
    val conf = new Configuration()
    conf.set("fs.defaultFS", FieldName.hdfsurl)
    val fileSystem = FileSystem.get(conf)
    //要读取的日志目录
    val paths: String = FieldName.jsonpath
    val fs = fileSystem.listStatus(new Path(paths + today))
    val listPath = FileUtil.stat2Paths(fs)

    val json_paths = new collection.mutable.ArrayBuffer[String]()

    var savePathName = ""
    for (readPath <- listPath) {

      if (readPath.toString.contains(s"$today$hour")) {
        json_paths.append(readPath.toString)
      }

    }
    val DS: DataFrame = spark.read.text(json_paths: _*)
    savePathName = s"$today$hour"
    etlHourJson(DS, aldTimeUtil, today, savePathName) //清洗统计的json
    errorEtlHourJson(DS, aldTimeUtil, today, savePathName) //清洗错误日志的json
    parquetHourEtl(spark, aldTimeUtil, today, hour) //清洗统计的parquet
    errorParquetHourEtl(spark, aldTimeUtil, today, hour) //清洗错误的parquet

    //事件单独处理 eventETL
    //    new eventETLHour(spark, aldTimeUtil, today, hour) //事件的清洗


  }

  def errorEtlHourJson(DS: DataFrame, aldTimeUtil: TimeUtil, today: String, savePathName: String) {

    val conf = new Configuration()
    conf.set("fs.defaultFS", FieldName.hdfsurl)
    val fileSystem = FileSystem.get(conf)
    if (fileSystem.exists(new Path(FieldName.errpath + s"/$today/etl-$savePathName"))) {
      fileSystem.delete(new Path(FieldName.errpath + s"/$today/etl-$savePathName"), true)
    }
    DS.toJSON.rdd.map(line => {
      try {
        if (line != null) {
          if (line.contains("ald_error_message") || line.contains("js_err")) {

            val rule = new regex_rule
            val js1 = JSON.parseObject(line)
            val jsline = js1.get("value").toString
            val js = JSON.parseObject(jsline)
            if (js.containsKey("ak")) {
              val ak = js.get("ak").toString
              if (rule.chenkak(ak)) {
                var jsonetl = new JSONObject()
                //获得所对应的时间戳
                if (js.containsKey("ts") && js.get("ts") != null && !js.get("ts").equals("")) {
                  val stvale = js.get("ts").toString
                  if (stvale.length == 13) {
                    val sss = stvale.toLong
                    jsonetl.put("st", sss)
                  }
                } else if (js.containsKey("st") && js.get("st") != null && !js.get("st").equals("")) {
                  val stvale = js.get("st").toString
                  if (stvale.length == 13) {
                    val sss = stvale.toLong
                    jsonetl.put("st", sss)
                  }
                }
                if (jsonetl.get("st") != null) {
                  val s = jsonetl.get("st").toString
                  if (StringUtils.isNumeric(s)) {
                    jsonetl.put("day", aldTimeUtil.st2Day(s.toLong))
                    jsonetl.put("hour", aldTimeUtil.st2hour(s.toLong))
                  }
                  else {
                    jsonetl.put("day", "null")
                    jsonetl.put("hour", "null")
                  }
                }

                //-------------------------------
                if (js.containsKey("ct") && js.get("ct") != null && js.get("ct") != "") {
                  if (js.get("ct").toString.contains("{")) {
                    val ct = js.get("ct").toString
                    //去掉ct字段中的反斜杠 /
                    val ctss = ct.replaceAll("\"", "\'")
                    jsonetl.put("ct", ctss)
                  } else if (js.get("ct").toString.substring(0, 1) == "\"") {
                    val ct = js.get("ct").toString
                    val cts: String = ct.replaceAll("\"", "")
                    jsonetl.put("ct", cts)
                  } else {
                    val ct = js.get("ct").toString
                    jsonetl.put("ct", ct)
                  }
                }
                if (!js.containsKey("ct")) {
                  jsonetl.put("ct", "null")
                }
                //去掉dr的双引号
                if (js.containsKey("dr") && js.get("dr") != null && !js.get("dr").equals("")) {
                  val drs = js.get("dr").toString
                  if (rule.isNumdr(drs)) {
                    val drss = drs.toLong
                    jsonetl.put("dr", drss)
                  } else {
                    jsonetl.put("dr", 0)
                  }
                }
                //处理其他字段 这些字段不要特殊处理 在filename 中添加就可以
                val fName: String = FieldName.ff
                val fields: Array[String] = fName.split(",")
                for (field <- fields) {
                  if (js.containsKey(field) && js.get(field) != null) {
                    jsonetl.put(field, js.get(field).toString)
                  } else {
                    jsonetl.put(field, "null")
                  }
                }
                jsonetl
              }
            }
          }
        }
      } catch {
        case e: Exception => e.printStackTrace()
      }

    }).filter(!_.toString.contains("()")).saveAsTextFile(FieldName.errpath + s"/$today/etl-$savePathName")


  }


  def etlHourJson(DS: DataFrame, aldTimeUtil: TimeUtil, today: String, savePathName: String) {

    val conf = new Configuration()
    conf.set("fs.defaultFS", FieldName.hdfsurl)
    val fileSystem = FileSystem.get(conf)
    if (fileSystem.exists(new Path(FieldName.etlpath + s"/$today/etl-$savePathName"))) {
      fileSystem.delete(new Path(FieldName.etlpath + s"/$today/etl-$savePathName"), true)
    }
    println("-----------etlpath------------")
    println(FieldName.etlpath + s"/$today/etl-$savePathName")
    DS.toJSON.rdd.map(line => {
      try {
        var jsonetl = new JSONObject()
        if (line != null) {
          //创建ak规则对象
          val akRule = new regex_rule
          //创建json对象存放处理的数据
          val js1 = JSON.parseObject(line)
          val jsline = js1.get("value").toString
          val js = JSON.parseObject(jsline)
          if (js.containsKey("ak")) {
            val ak = js.get("ak").toString
            if (akRule.chenkak(ak)) {
              //获得所对应的时间戳
              if (js.containsKey("ts") && js.get("ts") != null && !js.get("ts").equals("")) {
                val stvale = js.get("ts").toString
                if (stvale.length == 13) {
                  val st = stvale.toLong
                  jsonetl.put("st", st)
                }
              } else if (js.containsKey("st") && js.get("st") != null && !js.get("st").equals("")) {
                val stvale = js.get("st").toString
                if (stvale.length == 13) {
                  val st = stvale.toLong
                  jsonetl.put("st", st)
                }
              }
              if (jsonetl.get("st") != null) {
                val st = jsonetl.get("st").toString
                if (StringUtils.isNumeric(st)) {
                  jsonetl.put("day", aldTimeUtil.st2Day(st.toLong))
                  jsonetl.put("hour", aldTimeUtil.st2hour(st.toLong))
                }
                else {
                  jsonetl.put("day", "null")
                  jsonetl.put("hour", "null")
                }
              }
              //处理ct
              if (js.containsKey("ct") && js.get("ct") != null) {
                val ct = js.get("ct").toString
                val err = "error"
                if (ct.toUpperCase.indexOf(err.toUpperCase) != -1) {
                  jsonetl.put("error_messsage", ct)
                  jsonetl.put("ct", "null")
                }
              }
              if (!js.containsKey("ct")) {
                jsonetl.put("ct", "null")
              }
              //-------------------------------
              if (js.containsKey("ct") && js.get("ct") != null && js.get("ct") != "") {
                if (js.get("ct").toString.contains("{")) {
                  val ct = js.get("ct").toString
                  //去掉ct字段中的反斜杠 /
                  val s = ct.replaceAll("\"", "\'")
                  jsonetl.put("ct", s)
                } else if (js.get("ct").toString.substring(0, 1) == "\"") {
                  val ct = js.get("ct").toString
                  val cts: String = ct.replaceAll("\"", "")
                  jsonetl.put("ct", cts)
                } else {
                  val ct = js.get("ct").toString
                  jsonetl.put("ct", ct)
                }
              }
              //调整 ct 字段 变成一个嵌套json
              if (js.containsKey("error_messsage") && js.get("error_messsage") != null && js.get("error_messsage") != "") {
                val errorlog = js.get("error_messsage").toString
                jsonetl.put("error_messsage", errorlog)
              }
              //处理分享链
              if (js.containsKey("tp") && js.get("tp") != null && js.get("tp").toString.equals("ald_share_chain")) {
                if (js.get("ct") != null && js.get("ct").toString.contains("{")) {
                  val ct = js.get("ct").toString
                  val s = ct.replaceAll("\"", "\'")
                  val ctj = JSON.parseObject(s)
                  if (ctj.containsKey("path") && ctj.containsKey("chain")) {
                    jsonetl.put("ct_path", ctj.get("path").toString)
                    jsonetl.put("ct_chain", ctj.get("chain").toString)
                  }
                }
              }
              //去掉dr的双引号
              if (js.containsKey("dr") && js.get("dr") != null && !js.get("dr").equals("")) {
                val drs = js.get("dr").toString
                if (akRule.isNumdr(drs)) {
                  val drss = drs.toLong
                  jsonetl.put("dr", drss)
                } else {
                  jsonetl.put("dr", 0)
                }
              }
              //去掉ag字段的反斜线
              if (js.containsKey("ag") && js.get("ag") != null && js.get("ct") != "") {
                if (js.get("ag").toString.contains("{")) {
                  val ct = js.get("ag").toString
                  //去掉ct字段中的反斜杠 /
                  val ctss = ct.replaceAll("\"", "\'")
                  jsonetl.put("ag", ctss)
                } else if (js.get("ag").toString.substring(0, 1) == "\"") {
                  val ct = js.get("ag").toString
                  val cts: String = ct.replaceAll("\"", "")
                  jsonetl.put("ag", cts)
                } else {
                  val ct = js.get("ag").toString
                  jsonetl.put("ag", ct)
                }
              }
              // 广告外链追踪
              if (js.containsKey("ag") && js.get("ag") != null && js.get("ag").toString.contains("{")) {
                val ct = js.get("ag").toString
                //将ct中的双引号和反斜线替换成单引号
                val s = ct.replaceAll("\"", "\'")
                val agj = JSON.parseObject(s)
                if (agj.containsKey("ald_link_key") && agj.containsKey("ald_position_id") && agj.containsKey("ald_media_id")) {
                  jsonetl.put("ag_ald_link_key", agj.get("ald_link_key").toString)
                  jsonetl.put("ag_ald_position_id", agj.get("ald_position_id").toString)
                  jsonetl.put("ag_ald_media_id", agj.get("ald_media_id").toString)
                }

              }
              else {
                jsonetl.put("ag_ald_link_key", "null")
                jsonetl.put("ag_ald_position_id", "null")
                jsonetl.put("ag_ald_media_id", "null")
              }
              //不需要处理的字段从FieldName中添加 需要处理的就不要放在filedName中了
              val fName: String = FieldName.ff
              val fields: Array[String] = fName.split(",")
              for (field <- fields) {
                if (js.containsKey(field) && js.get(field) != null) {
                  jsonetl.put(field, js.get(field).toString)
                } else {
                  jsonetl.put(field, "null")
                }
              }
            }
            jsonetl
          }
        }
      } catch {
        case e: Exception => e.printStackTrace()
      }
    }).filter(!_.toString.contains("()")).saveAsTextFile(FieldName.etlpath + s"/$today/etl-$savePathName")
  }


  def parquetHourEtl(spark: SparkSession, aldTimeUtil: TimeUtil, today: String, hour: String) {

    val conf = new Configuration()
    conf.set("fs.defaultFS", FieldName.hdfsurl)
    val fileSystem = FileSystem.get(conf)
    //今天的日期加上小时用来判断处理某个小时的文件
    val th = today + hour
    //获取etl后的json路径
    val paths: String = FieldName.etlpath
    val fs = fileSystem.listStatus(new Path(paths + today))
    //读取到今天的etl-json路径下的所有文件
    val listPath = FileUtil.stat2Paths(fs)


    for (readPath <- listPath) {
      //for循环处理判读如果包含今天上一个小时的问题件夹则进行处理
      if (readPath.toString.contains(s"$th")) {
        //对文件路径进行切分 目的是为了存数据的文件夹名称
        val pathnames = readPath.toString.split("/")
        //取切分后的最后一个为名称
        val pathname = pathnames(pathnames.length - 1)
        try {

          if (fileSystem.exists(new Path(FieldName.parquetpath + s"$today/$pathname"))) {
            fileSystem.delete(new Path(FieldName.parquetpath + s"$today/$pathname"), true)
          }

          val df = spark.read.option("mergeSchema", "true").json(s"$readPath")
          //            .repartition(100)
          df.repartition(8).write.parquet(FieldName.parquetpath + s"$today/$pathname")
        } catch {
          case e: Exception => e.printStackTrace()
          case _: Exception => println("转parquet出错:" + readPath.toString)
        }

      }
    }

  }


  def errorParquetHourEtl(spark: SparkSession, aldTimeUtil: TimeUtil, today: String, hour: String) {


    //今天的日期加上小时
    val th = today + hour
    val conf = new Configuration()
    conf.set("fs.defaultFS", FieldName.hdfsurl)
    val fileSystem = FileSystem.get(conf)
    val paths: String = FieldName.errpath
    //读取到今天的 erroretl-json路径下的所有文件
    val fs = fileSystem.listStatus(new Path(paths + today))
    val listPath = FileUtil.stat2Paths(fs)
    for (d <- listPath) {
      //for循环处理判读如果包含今天上一个小时的问题件夹则进行处理
      if (d.toString.contains(s"$th")) {
        //对文件路径进行切分 目的是为了存数据的文件夹名称
        val pathnames = d.toString.split("/")
        //取切分后的最后一个为名称
        val pathname = pathnames(pathnames.length - 1)
        try {

          if (fileSystem.exists(new Path(FieldName.errparquet + s"$today/$pathname"))) {
            fileSystem.delete(new Path(FieldName.errparquet + s"$today/$pathname"), true)
          }

          val df = spark.read.option("mergeSchema", "true").json(s"$d")
          //            .repartition(100)
          df.repartition(8).write.parquet(FieldName.errparquet + s"$today/$pathname")
        } catch {
          case e: Exception => e.printStackTrace()
          case _: Exception => println("转parquet出错:" + d.toString)
        }
      }
    }
  }


  def eventETLHour(spark: SparkSession, aldTimeUtil: TimeUtil, today: String, hour: String) {

    //判断是否包含某个小时的文件 需要带的字符串
    val isHour = today + hour
    @transient
    val conf = new Configuration()
    conf.set("fs.defaultFS", FieldName.hdfsurl)
    @transient
    val fileSystem = FileSystem.get(conf)
    //要读取的日志目录
    @transient
    val paths: String = FieldName.parquetpath
    @transient
    val fs = fileSystem.listStatus(new Path(paths + today))
    //当前某个小时的所有文件夹
    @transient
    val listPath = FileUtil.stat2Paths(fs)
    for (readPath <- listPath) {
      //通过for循环处理读判断是否包含要处理小时的文件夹
      if (readPath.toString.contains(s"$isHour")) {
        println(readPath)
        val df = spark.read.option("mergeSchema", "true").parquet(s"$readPath").filter(col("ev") === "event")
        //切分出一个表名要求每次循环里面的名字都不是不一样的
        val pathnames = readPath.toString.split("/")
        val pathname = pathnames(pathnames.length - 1)
        val tablenames = pathname.split("-")
        val tableOne = tablenames(tablenames.length - 1)
        val tableTwo = tablenames(tablenames.length - 2)
        val tablename = tableOne + tableTwo
        val rdd = df.toJSON.rdd.map(
          line => {
            val jsonLine = JSON.parseObject(line)
            val ak: String = jsonLine.get("ak").toString
            val tp: String = jsonLine.get("tp").toString
            var st = jsonLine.get("st")
            if (st == null) {
              st = ""
            } else { // st 字段为空则让 st = ""
              st = st.toString //  否则就直接转字符串
            }
            val ss = ak + tp
            Row(ak, tp, st, ss)
          }
        ).distinct()
        //指定dataframe的类型
        val schema = StructType(
          List(
            StructField("ak", StringType, true),
            StructField("tp", StringType, true),
            StructField("st", StringType, true),
            StructField("ss", StringType, true)
          )
        )
        val oneDF: DataFrame = spark.createDataFrame(rdd, schema)
        //初始化dataframe

        oneDF.createTempView(s"tmp$tablename")
        //udf  函数  (将 tp 和 ak 加密)
        spark.udf.register("udf", ((s: String) => toHex(MessageDigest.getInstance("MD5").digest(s.getBytes("UTF-8")))))

        def toHex(bytes: Array[Byte]): String = bytes.map("%02x".format(_)).mkString("")


        spark.udf.register("time2date", (s: String) => {
          val regex = """([0-9]+)""".r
          //将时间 切成 11 位的int 类型
          var res = ""
          try {
            res = s.substring(0, s.length - 3) match {
              case regex(num) => num
              case _ => "0"
            }
          } catch {
            case e: StringIndexOutOfBoundsException =>
              println(s"$s ：这条数据长度不够")
          }

          val stime = Integer.parseInt(res)
          val stimeLong: Long = stime.toLong * 1000;
          val sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
          sdf.format(stimeLong)
        })

        val result = spark.sql(s"select ak,tp,udf(ss),time2date(st) from tmp$tablename").distinct()

        //入库到mysql 表中
        var conn: Connection = null
        result.foreachPartition((rows: Iterator[Row]) => {
          val conn = MySqlPool.getJdbcConn()
          conn.setAutoCommit(false)
          val statement = conn.createStatement
          try {
            conn.setAutoCommit(false)
            rows.foreach(r => {
              val ak = r(0)
              val ev_id = r(1)
              val event_key = r(2)
              var ev_name = ""
              r(1) match {
                case "ald_reachbottom" => ev_name = "页面触底(阿拉丁默认)"
                case "ald_pulldownrefresh" => ev_name = "下拉刷新(阿拉丁默认)"
                case _ => ev_name = r(1).toString
              }

              val ev_time = r(3)
              //如果数据库已经存在ev_id 这里只更新时间
              val sql = s"insert into ald_event (app_key,ev_id,event_key,ev_name,ev_update_time) values ('${ak}','${ev_id}','${event_key}','${ev_name}','${ev_time}') ON DUPLICATE KEY UPDATE ev_update_time='${ev_time}'"
              statement.addBatch(sql)
            })
            statement.executeBatch
            conn.commit()
          } catch {
            case e: Exception => e.printStackTrace()
              conn.close()
          }
        })
      }
    }
  }

}




