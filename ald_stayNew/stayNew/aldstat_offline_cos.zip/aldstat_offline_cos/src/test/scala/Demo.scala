/**
  * Created by wangtaiyang on 2018/4/6. 
  */
object Demo {
  def main(args: Array[String]): Unit = {
    val a=Array(1,2,3)
    println(a(1))
  }

}
